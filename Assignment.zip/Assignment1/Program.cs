﻿using System;
using System.Collections.Generic;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a new dictionary of strings, with string keys.
            //
            Dictionary<string, string> movement =
                new Dictionary<string, string>();

            // Add some elements to the dictionary. There are no
            // duplicate keys, but some of the values are duplicates.
            movement.Add("Up", "Basic Up Move");
            movement.Add("Down", "Basic Down Move");
            movement.Add("Left", "Basic Left Move");
            movement.Add("Right", "Basic Right Move");
            movement.Add("Combo", "Up Up Down Down Combo Move");


            string input = Console.ReadLine();
            string move;
            if (movement.TryGetValue(input, out move)) // try and get the move
            {
                Console.WriteLine(move);
            }
           }
    }
}
