﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment3
{
   abstract class SpliDirectory
    {
        void SplitDirectoryFile(string path, out string directory, out string file);
    }
}
