﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Assignment2;
namespace UnitTestAssignment2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Creation()
        {
            Stack<int> s = new Stack<int>(3);
            Assert.AreEqual(0, s.Size);
        }

        [TestMethod]
        public void Push_Pop()
        {
            Assert.AreEqual(3, value);
            Assert.AreEqual(2, s.Size);
        }


        [TestMethod]
        public void Too_Much_Pop()
        {
            Assert.Throws<ExpenditureProhibitedException>(() => s.Pop());
        }


        [TestMethod]
        public void Too_Much_Push()
        {
            Assert.Throws<ExceededSizeException>(() => s.Push(4));
        }


        [TestMethod]
        public void Peek_Exception()
        {
            Assert.Throws<ExpenditureProhibitedException>(() => s.Peek());
        }

        [TestMethod]
        public void Peek_Element()
        {
            int value = s.Peek();
            Assert.AreEqual(2, value);
            Assert.AreEqual(2, s.Size);
        }


    }
}
